import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.util.HashMap;
import java.util.Map;

public class DegreeApp extends Application {
    private Student student = new Student();
    private int moduleCount;

    @Override
    public void start(Stage primaryStage) {
        Label titleLabel = new Label("Degree Classification Calculator");

        // Input for number of modules
        Label countLabel = new Label("Enter number of modules:");
        TextField countInput = new TextField();
        countInput.setPrefWidth(100); // Narrower width for input field
        Button setCountButton = new Button("Set Module Count");

        // Module input fields container
        VBox moduleInputs = new VBox(10);
        ScrollPane scrollPane = new ScrollPane(moduleInputs); // Wrap in a ScrollPane
        scrollPane.setFitToWidth(true);
        scrollPane.setPrefHeight(300); // Limit height for scrollability

        // Results
        Label resultLabel = new Label();
        Label classificationLabel = new Label();

        // Calculate button
        Button calculateButton = new Button("Calculate Classification");
        calculateButton.setDisable(true);

        // Set module count logic
        setCountButton.setOnAction(e -> {
            try {
                moduleCount = Integer.parseInt(countInput.getText().trim());
                if (moduleCount <= 0) {
                    throw new NumberFormatException("Module count must be positive.");
                }

                // Clear previous inputs and generate new ones
                moduleInputs.getChildren().clear();
                for (int i = 1; i <= moduleCount; i++) {
                    Label moduleLabel = new Label("Module " + i + ":");

                    TextField moduleNameInput = new TextField();
                    moduleNameInput.setPromptText("Module Name");
                    moduleNameInput.setPrefWidth(200);

                    TextField moduleCodeInput = new TextField();
                    moduleCodeInput.setPromptText("Module Code");
                    moduleCodeInput.setPrefWidth(100);

                    TextField creditInput = new TextField();
                    creditInput.setPromptText("Credits (e.g., 15)");
                    creditInput.setPrefWidth(80);

                    TextField scoreInput = new TextField();
                    scoreInput.setPromptText("Score (0-100)");
                    scoreInput.setPrefWidth(80);

                    VBox moduleBox = new VBox(5, moduleLabel, moduleNameInput, moduleCodeInput, creditInput, scoreInput);
                    moduleInputs.getChildren().add(moduleBox);
                }

                calculateButton.setDisable(false);
            } catch (NumberFormatException ex) {
                resultLabel.setText("Error: " + ex.getMessage());
            }
        });

        // Calculate classification logic
        calculateButton.setOnAction(e -> {
            student.clearGrades();

            for (int i = 0; i < moduleInputs.getChildren().size(); i++) {
                VBox moduleBox = (VBox) moduleInputs.getChildren().get(i);
                TextField moduleNameInput = (TextField) moduleBox.getChildren().get(1);
                TextField moduleCodeInput = (TextField) moduleBox.getChildren().get(2);
                TextField creditInput = (TextField) moduleBox.getChildren().get(3);
                TextField scoreInput = (TextField) moduleBox.getChildren().get(4);

                try {
                    String moduleName = moduleNameInput.getText().trim();
                    String moduleCode = moduleCodeInput.getText().trim();
                    double credit = Double.parseDouble(creditInput.getText().trim());

                    // Validate score input as integer and within range 0-100
                    int score;
                    try {
                        score = Integer.parseInt(scoreInput.getText().trim());
                        if (score < 0 || score > 100) {
                            throw new IllegalArgumentException("Score must be between 0 and 100.");
                        }
                    } catch (NumberFormatException ex) {
                        throw new IllegalArgumentException("Score must be a valid integer.");
                    }

                    // Pass Marks Validation (must be 40 or above)
                    if (score < 40) {
                        throw new IllegalArgumentException("Score must be at least 40% to pass.");
                    }

                    // Categorical Marks Validation (must be an integer)
                    if (score != (int) score) {
                        throw new IllegalArgumentException("Score must be an integer.");
                    }

                    // Module Codes Validation (extract level from the first digit after the letter)
                    if (moduleCode.length() < 4) {
                        throw new IllegalArgumentException("Invalid module code: " + moduleCode);
                    }

                    int levelFromCode = Character.getNumericValue(moduleCode.charAt(2)); // Extract level from module code
                    student.addGrade(new Grade(moduleName, moduleCode, score, credit));
                } catch (Exception ex) {
                    resultLabel.setText("Error in module " + (i + 1) + ": " + ex.getMessage());
                    return;
                }
            }

            // Credits Per Level Validation
            Map<Integer, Double> creditsPerLevel = new HashMap<>();
            for (Grade grade : student.getGrades()) {
                int level = Character.getNumericValue(grade.getModuleCode().charAt(2));  // Level from module code
                creditsPerLevel.put(level, creditsPerLevel.getOrDefault(level, 0.0) + grade.getCredit());
            }

            for (Map.Entry<Integer, Double> entry : creditsPerLevel.entrySet()) {
                if (entry.getValue() != 120) {
                    resultLabel.setText("Error: Total credits for Level " + entry.getKey() + " must be 120.");
                    return;
                }
            }

            // Overall Grade and Classification
            double overallGrade = student.calculateOverallGrade();
            String classification = student.getClassification();

            resultLabel.setText("Overall Grade: " + String.format("%.2f", overallGrade));
            classificationLabel.setText("Final Classification: " + classification);
        });

        // Layout
        VBox layout = new VBox(10);
        layout.getChildren().addAll(
                titleLabel,
                countLabel, countInput, setCountButton,
                scrollPane, // Use ScrollPane for the module inputs
                calculateButton,
                resultLabel,
                classificationLabel
        );

        // Scene setup
        Scene scene = new Scene(layout, 600, 600);
        primaryStage.setTitle("Degree Classification Calculator");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
