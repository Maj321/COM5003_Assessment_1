public class Grade {
    private String moduleName;
    private String moduleCode;
    private double score;
    private double credit;

    public Grade(String moduleName, String moduleCode, double score, double credit) {
        this.moduleName = moduleName;
        this.moduleCode = moduleCode;
        this.score = score;
        this.credit = credit;
    }

    public double getWeightedScore() {
        return score * credit;
    }

    public String getModuleName() {
        return moduleName;
    }

    public String getModuleCode() {
        return moduleCode;
    }

    public double getScore() {
        return score;
    }

    public double getCredit() {
        return credit;
    }
}
