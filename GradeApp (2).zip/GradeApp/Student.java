import java.util.ArrayList;
import java.util.List;

public class Student {
    private List<Grade> grades;

    public Student() {
        this.grades = new ArrayList<>();
    }

    public void addGrade(Grade grade) {
        grades.add(grade);
    }

    public void clearGrades() {
        grades.clear();
    }

    public double calculateOverallGrade() {
        double totalWeightedScore = 0;
        double totalCredits = 0;

        for (Grade grade : grades) {
            totalWeightedScore += grade.getWeightedScore();
            totalCredits += grade.getCredit();
        }

        return totalCredits > 0 ? totalWeightedScore / totalCredits : 0;
    }

    public String getClassification() {
        double overallGrade = calculateOverallGrade();
        if (overallGrade >= 70) return "First Class";
        if (overallGrade >= 60) return "Upper Second Class";
        if (overallGrade >= 50) return "Lower Second Class";
        if (overallGrade >= 40) return "Third Class";
        return "Fail";
    }

    public List<Grade> getGrades() {
        return grades;
    }
}
