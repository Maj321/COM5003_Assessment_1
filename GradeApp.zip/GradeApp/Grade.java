public class Grade {
    private String moduleName;
    private double gradeValue;
    private double weighting;

    public Grade(String moduleName, double gradeValue, double weighting) {
        this.moduleName = moduleName;
        this.gradeValue = gradeValue;
        this.weighting = weighting;
    }

    public double getWeightedGrade() {
        return gradeValue * weighting;
    }

    public String getModuleName() {
        return moduleName;
    }

    public double getGradeValue() {
        return gradeValue;
    }

    public double getWeighting() {
        return weighting;
    }
}
