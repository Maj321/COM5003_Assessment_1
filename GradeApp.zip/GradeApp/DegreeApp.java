import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class DegreeApp extends Application {
    private Student student = new Student();

    @Override
    public void start(Stage primaryStage) {
        // GUI Components
        Label titleLabel = new Label("Degree Classification Calculator");
        Label moduleLabel = new Label("Module Name:");
        TextField moduleInput = new TextField();
        Label gradeLabel = new Label("Grade:");
        TextField gradeInput = new TextField();
        Label weightLabel = new Label("Weighting (e.g., 0.25):");
        TextField weightInput = new TextField();
        Button addButton = new Button("Add Grade");
        Button calculateButton = new Button("Calculate Classification");
        Label resultLabel = new Label();
        Label classificationLabel = new Label();

        // Layout
        VBox layout = new VBox(10);
        layout.getChildren().addAll(
                titleLabel, moduleLabel, moduleInput, 
                gradeLabel, gradeInput, weightLabel, weightInput, 
                addButton, calculateButton, resultLabel, classificationLabel
        );

        // Add Grade Button Logic
        addButton.setOnAction(e -> {
            String module = moduleInput.getText();
            try {
                double grade = Double.parseDouble(gradeInput.getText());
                double weight = Double.parseDouble(weightInput.getText());
                student.addGrade(new Grade(module, grade, weight));
                resultLabel.setText("Grade added: " + module + " - " + grade + " (" + weight + ")");
                moduleInput.clear();
                gradeInput.clear();
                weightInput.clear();
            } catch (NumberFormatException ex) {
                resultLabel.setText("Error: Invalid grade or weight entered.");
            }
        });

        // Calculate Button Logic
        calculateButton.setOnAction(e -> {
            double overallGrade = student.calculateOverallGrade();
            String classification = student.getClassification();
            resultLabel.setText("Overall Grade: " + overallGrade);
            classificationLabel.setText("Classification: " + classification);
        });

        // Scene Setup
        Scene scene = new Scene(layout, 400, 400);
        primaryStage.setTitle("Degree Classification Calculator");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
